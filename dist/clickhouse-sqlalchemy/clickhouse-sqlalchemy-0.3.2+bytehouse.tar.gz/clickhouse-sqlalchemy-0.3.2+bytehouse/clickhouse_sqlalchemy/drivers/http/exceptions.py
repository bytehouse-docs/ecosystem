
class HTTPException(Exception):
    code = None
