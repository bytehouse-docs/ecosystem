from sqlalchemy import text
from sqlalchemy.util import to_list

from .base import Engine, KeysExpressionOrColumn
from .util import parse_columns


class CnchMergeTree(Engine):

    __visit_name__ = 'cnch_merge_tree'

    def __init__(
            self,
            partition_by=None,
            order_by=None,
            primary_key=None,
            sample_by=None,
            ttl=None,
            **settings
    ):
        self.partition_by = None
        if partition_by is not None:
            self.partition_by = KeysExpressionOrColumn(*to_list(partition_by))

        self.order_by = None
        if order_by is not None:
            self.order_by = KeysExpressionOrColumn(*to_list(order_by))

        self.primary_key = None
        if primary_key is not None:
            self.primary_key = KeysExpressionOrColumn(*to_list(primary_key))

        self.sample_by = None
        if sample_by is not None:
            self.sample_by = KeysExpressionOrColumn(*to_list(sample_by))

        self.ttl = None
        if ttl is not None:
            self.ttl = KeysExpressionOrColumn(*to_list(ttl))

        self.settings = settings
        super(CnchMergeTree, self).__init__()

    def _set_parent(self, table, **kwargs):
        super(CnchMergeTree, self)._set_parent(table, **kwargs)
        if self.partition_by is not None:
            self.partition_by._set_parent(table, **kwargs)
        if self.order_by is not None:
            self.order_by._set_parent(table, **kwargs)
        if self.primary_key is not None:
            self.primary_key._set_parent(table, **kwargs)
        if self.sample_by is not None:
            self.sample_by._set_parent(table, **kwargs)
        if self.ttl is not None:
            self.ttl._set_parent(table, **kwargs)

    @classmethod
    def wrap_with_text(cls, table, cols):
        return [x if x in table.columns else text(x) for x in cols]

    @classmethod
    def _reflect_cnch_merge_tree(
            cls, table, partition_key=None, sorting_key=None, primary_key=None,
            sampling_key=None, ttl=None, **kwargs):

        # TODO: reflect settings
        rv = {}
        if partition_key:
            partition_by = parse_columns(partition_key)
            rv['partition_by'] = cls.wrap_with_text(table, partition_by)
        if sorting_key:
            order_by = parse_columns(sorting_key)
            rv['order_by'] = cls.wrap_with_text(table, order_by)
        if primary_key:
            primary_key = parse_columns(primary_key)
            rv['primary_key'] = cls.wrap_with_text(table, primary_key)
        if sampling_key:
            sample_by = parse_columns(sampling_key)
            rv['sample_by'] = cls.wrap_with_text(table, sample_by)
        if ttl:
            rv['ttl'] = cls.wrap_with_text(table, parse_columns(ttl))

        return rv

    @classmethod
    def reflect(cls, table, engine_full, **kwargs):
        return cls(**cls._reflect_cnch_merge_tree(table, **kwargs))
